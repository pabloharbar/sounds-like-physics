/*:
 # Meet Pablo
 
 ## You are talking with Pablo.

 ### An imaginary character who looks physically like a projection of myself.
 
 ### Over the years Pablo had his hearing compromised due to being exposed to loud noises.
 
 ### And it made him very sad since he enjoyed music so much. That is why he may seem a little grumpy.
 
 ### The loss of high frequency hearing is one of the most common ways of hearing loss. Frequencies from 2000 to 8000 Hertz can't be heard. Hearing accuracy loss is one of the first signals of hearing loss.
 
 ![Hearig Cut](hearing.png)
 
 ### Every sound heard is processed inside the cochlea, in tiny cells that can translate vibrations into information. High pitch sounds are processed in the base of the cochlea (1), which is more susceptible to damage, whereas low pitch sounds are processed in (2).

 
*/
//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//


import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 600))

let scene = GameScene(size: CGSize(width: 800, height: 600))
scene.scaleMode = .aspectFit
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code

