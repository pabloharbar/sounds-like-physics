/*: primeira pagina
 # The Experiment
 
### Despite his mood he really needs your help calibrating the device he developed. He can`t hear certain sound frequencies.

### The device is called Theremin, in honor to the instrument created by Leon Theremin.

### The instrument outputs sound based on two parameters:

  * #### Pitch
  * #### Amplitude, of the wave synthetized.

 ### That's what Pablo wants you to learn with this experiment.
 
 
 
*/
//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//


//import PlaygroundSupport
//import SpriteKit
//import UIKit
//import BookCore
//
//let mainView = UIView(frame: CGRect(x: 0, y: 0, width: 800, height: 600))
//
//
//let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 600))
//
//let scene = GameScene2(size: CGSize(width: 800, height: 600))
//scene.scaleMode = .aspectFit
//sceneView.presentScene(scene)
//
//mainView.contentMode = .ScaleAspectFit
//mainView.addSubview(sceneView)
//
//PlaygroundPage.current.liveView = mainView
//PlaygroundPage.current.needsIndefiniteExecution = true

import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore


PlaygroundPage.current.liveView = ViewController()
//PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code

