//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

//: A SpriteKit based Playground

//: A SpriteKit based Playground
import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 600))

let scene = GameScene3(size: CGSize(width: 800, height: 600))
scene.scaleMode = .aspectFit
sceneView.presentScene(scene)
sceneView.isMultipleTouchEnabled = true

PlaygroundPage.current.liveView = sceneView



//#-end-hidden-code
/*: primeira pagina
# The Theremin
 
 
 ### Now it's the time to have fun and explore the device created by Pablo.
 
 
 ## Instructions:
 * ### Whenever you swipe up, the sound *Amplitude* is increased.
 * ### Whenever you swipe to the right, the sound *Pitch* is increased.
 * ### Whenever you release the swipe, the instrument and the color spectrum are alternated.
 
 ___
  
  - Important: In order to run smoothly and avoid animation delay, please **disable results**. That can be done by clicking the icon on the left side of "Run my code" and deactivating the option "See results". The algorithm is a little bit sensitive when overwhelmed with tasks so it might break if stressed.
  
 ---
 
 #### Green color spectrum sounds like a bass and the yellow spectrum sounds like a piano.
 
 #### You can also set manually the instrument for the Theremin or turn off the alternation between the two instruments.
 
* #### Use scene.set = 0 for the bass set
* #### Use scene.set = 1 for the piano set
 
*/
scene.set = 1
scene.alternate = true
