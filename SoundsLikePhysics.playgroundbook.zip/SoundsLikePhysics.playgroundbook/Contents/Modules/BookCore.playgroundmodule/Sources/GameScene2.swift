import SpriteKit
import PlaygroundSupport
import AVFoundation
import UIKit

public class GameScene2: SKScene {
    var background = SKSpriteNode(imageNamed: "background2")
    var pablo = SKSpriteNode(imageNamed: "pablo4")
    var pablo2 = SKSpriteNode(imageNamed: "pablo9")
    var speech = SKSpriteNode(imageNamed: "speech4")
    var volumeSlider = SKSpriteNode(imageNamed: "slider1")
    var pitchSlider = SKSpriteNode(imageNamed: "slider2")
    var changeTexture = SKAction.setTexture(SKTexture(imageNamed: "pablo5"))
    
    
    let button = SKSpriteNode(imageNamed: "button9")
    
//    var controller = ViewController()
//    public var uiview = UIView(frame: CGRect(x: 0, y: 0, width: 260, height: 62))

    let startingPitch = Float(0)

    var audioFilePlayer: AVAudioPlayerNode!
    var auTimePitch: AVAudioUnitTimePitch!
    var audioFileBuffer: AVAudioPCMBuffer!

    var volume: Float = 0

    public func startSound(volume: Float) {
        // Do any additional setup after loading the view, typically from a nib.
        audioFilePlayer = AVAudioPlayerNode()
        do{
            let filePath: String = Bundle.main.path(forResource: "C2-Bass", ofType: "mp3")!
            let fileURL: URL = URL(fileURLWithPath: filePath)
            var audioFile: AVAudioFile!
            try audioFile = AVAudioFile(forReading: fileURL)
            let audioFormat = audioFile.processingFormat
            let audioFrameCount = UInt32(audioFile.length)
            audioFileBuffer = AVAudioPCMBuffer(pcmFormat: audioFormat, frameCapacity: audioFrameCount)
            try audioFile.read(into: audioFileBuffer)

            let mainMixer = audioEngine.mainMixerNode
            audioEngine.attach(audioFilePlayer)

            auTimePitch = AVAudioUnitTimePitch()
            auTimePitch.pitch = startingPitch
            audioEngine.attach(auTimePitch)
            audioEngine.connect(audioFilePlayer, to: auTimePitch, format: mainMixer.outputFormat(forBus: 0))
            audioEngine.connect(auTimePitch, to: mainMixer, format: mainMixer.outputFormat(forBus: 0))

            try audioEngine.start()
            audioFilePlayer.play()


            audioFilePlayer.scheduleBuffer(audioFileBuffer, at: nil, options:.loops, completionHandler: nil)

        }catch{
            print("erro start audio engine")
        }
    }
     
    
    var frameKey = 0
    
    public var shapeNodes: [SKShapeNode] = []
    
    public func changeText(texture: String) {
        changeTexture = SKAction.setTexture(SKTexture(imageNamed: texture))
    }
    
    let fadeOut = SKAction.fadeAlpha(to: 0, duration: 0.5)
    let move1 = SKAction.move(to: CGPoint(x: 0, y: 250), duration: 0.5)
    let move2 = SKAction.move(to: CGPoint(x: -150, y: 300), duration: 0.5)
    let move3 = SKAction.move(to: CGPoint(x: 130, y: 230), duration: 0.5)
    let wait = SKAction.wait(forDuration: 0.5)
    let wait1 = SKAction.wait(forDuration: 5)
    let wait2 = SKAction.wait(forDuration: 1)
    let wait3 = SKAction.wait(forDuration: 1.5)
    let appear = SKAction.fadeAlpha(to: 1, duration: 1)
    let appear1 = SKAction.fadeAlpha(to: 1, duration: 1.5)
    
    var setSlider1 = 0
    var setSlider2 = 0
    
    var action1 = 0

    func killSound() {
        audioFilePlayer.volume = 0
    }
    
    
    override public func didMove(to view: SKView) {
        var graphWidth: CGFloat = 1
        var amplitude: CGFloat = 0.18
        var periods = 3.0
        let bounds = CGRect(x: 0, y: 0, width: 260, height: 40)
        
        let width = bounds.width
        let height = bounds.height

        let origin = CGPoint(x: 0, y: 0)

        let path = UIBezierPath()
        path.move(to: origin)

        let limit = 360 * periods
        
        
        for angle in stride(from: 5.0, through: limit, by: 5.0) {
            var x = origin.x + CGFloat(angle / limit) * width * graphWidth
            var y = origin.y - CGFloat(sin(angle / 180.0 * .pi)) * height * amplitude
            path.addLine(to: CGPoint(x: x, y: y))
            
        }

        UIColor.red.setStroke()
        path.lineWidth = 20
  
        let shapeNode = SKShapeNode(path: path.cgPath)
        shapeNode.strokeColor = .green
        shapeNode.lineWidth = 3
        
        shapeNode.position.x = 268
        shapeNode.position.y = 364.2
        shapeNode.zPosition = 7
        
        shapeNodes.append(shapeNode)
        
        addChild(shapeNode)
       
        
        
        
        
        
        
        
        startSound(volume: 0.0)
        audioFilePlayer.volume = 0

        background.position.x = self.frame.midX
        background.position.y = self.frame.midY
        background.zPosition = 2
        
        pablo.position.x = -150
        pablo.position.y = 300
        pablo.zPosition = 3
        
        pablo2.position.x = -100
        pablo2.position.y = 300
        pablo2.zPosition = 3

        pablo.run(move1)
        
        speech.position = CGPoint(x: 400, y: 500)
        speech.zPosition = 3
        speech.alpha = 0
        
        speech.run(SKAction.sequence([wait,appear]))

        volumeSlider.position.x = 295.15
        volumeSlider.position.y = 195
        volumeSlider.zPosition = 3
        
        pitchSlider.position.x = 470.8
        pitchSlider.position.y = 223.1
        pitchSlider.zPosition = 3
        
        button.alpha = 0
        button.position.x = -200
        button.position.y = 400
        button.zPosition = 3

        addChild(button)
        addChild(pablo2)
        addChild(pitchSlider)
        addChild(volumeSlider)
        addChild(pablo)
        addChild(speech)
        addChild(background)

    }

    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint) {
        if button.contains(pos) {
            PlaygroundPage.current.navigateTo(page: .next)
        }
        
        if volumeSlider.contains(pos) {
            setSlider1 = 1
        }
        if pitchSlider.contains(pos) {
            setSlider2 = 1
        }
        
        if action1 == 1 {
            switch frameKey {
            case 0:
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "pablo6"))
                pablo.run(changeTexture)
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "speech6"))
                speech.run(SKAction.sequence([fadeOut,changeTexture,appear,wait1]))
                frameKey += 1
            case 1:
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "pablo7"))
                pablo.run(changeTexture)
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "speech7"))
                speech.run(SKAction.sequence([fadeOut,changeTexture,appear,wait1]))
                frameKey += 1
            case 2:
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "pablo8"))
                pablo.run(changeTexture)
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "speech8"))
                speech.run(SKAction.sequence([fadeOut,changeTexture,appear,wait1]))
                background.run(SKAction.setTexture(SKTexture(imageNamed: "background4")))
                frameKey += 1
            default:
                frameKey = 3
            }
            
        }
    }

    func touchMoved(toPoint pos : CGPoint) {
        if setSlider1 == 1 {
            if pos.y >= 180 && pos.y <= 264 {
                volumeSlider.position.y = pos.y
                audioFilePlayer.volume = 3 * Float(pos.y - 180) / 264
                
                var graphWidth: CGFloat = 1
                var periods: Float = 173 / 81 + 10 * Float(pitchSlider.position.x - 463.8) / 81
                var amplitude = Float(pos.y - 180) / 84
                let bounds = CGRect(x: 0, y: 0, width: 260, height: 40)

                let width = bounds.width
                let height = bounds.height

                let origin = CGPoint(x: 0, y: 0)

                let path = UIBezierPath()
                path.move(to: origin)

                let limit = 360 * periods


                for angle in stride(from: 5.0, through: limit, by: 5.0) {
                    var x = origin.x + CGFloat(angle / limit) * width * graphWidth
                    var y = origin.y - CGFloat(sin(angle / 180.0 * .pi) * amplitude) * height
                    path.addLine(to: CGPoint(x: x, y: y))

                }

                UIColor.red.setStroke()
                path.lineWidth = 20

                let shapeNode1 = SKShapeNode(path: path.cgPath)

                shapeNode1.strokeColor = .green
                shapeNode1.lineWidth = 3
                
                shapeNode1.position.x = 268
                shapeNode1.position.y = 364.2
                shapeNode1.zPosition = 7
                shapeNodes[0].removeFromParent()
                shapeNodes.remove(at: 0)
                shapeNodes.append(shapeNode1)
                addChild(shapeNodes[0])

            }
        }
        if setSlider2 == 1{
            if pos.x >= 463.8 && pos.x <= 544.8 {
                pitchSlider.position.x = pos.x
                auTimePitch.pitch = 1200 * Float(pos.x - 463.8) / 544.8 + 100

                var graphWidth: CGFloat = 1
                var periods: Float = 173 / 81 + 10 * Float(pos.x - 463.8) / 81
                var amplitude = Float(volumeSlider.position.y - 180) / 84
                let bounds = CGRect(x: 0, y: 0, width: 260, height: 40)

                let width = bounds.width
                let height = bounds.height

                let origin = CGPoint(x: 0, y: 0)

                let path = UIBezierPath()
                path.move(to: origin)

                let limit = 360 * periods


                for angle in stride(from: 5.0, through: limit, by: 5.0) {
                    var x = origin.x + CGFloat(angle / limit) * width * graphWidth
                    var y = origin.y - CGFloat(sin(angle / 180.0 * .pi) * amplitude) * height
                    path.addLine(to: CGPoint(x: x, y: y))

                }

                UIColor.red.setStroke()
                path.lineWidth = 20

                let shapeNode1 = SKShapeNode(path: path.cgPath)

                shapeNode1.strokeColor = .green
                shapeNode1.lineWidth = 3

                shapeNode1.position.x = 268
                shapeNode1.position.y = 364.2
                shapeNode1.zPosition = 7
                shapeNodes[0].removeFromParent()
                shapeNodes.remove(at: 0)
                shapeNodes.append(shapeNode1)
                addChild(shapeNodes[0])
            }
        }
    }
    


    func touchUp(atPoint pos : CGPoint) {
        if setSlider1 == 1 {
            if pos.y >= 250 && pos.y <= 260 && action1 == 0{
                pablo.run(SKAction.sequence([changeTexture,move1,wait2,wait1]))
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "speech5"))
                speech.run(SKAction.sequence([fadeOut,changeTexture,appear,wait1]))
                background.run(SKAction.setTexture(SKTexture(imageNamed: "background3")))
                action1 = 1
            }
        }
        if setSlider2 == 1 {
            if pos.x >= 520 && pos.x <= 530 && frameKey == 3 {
                pitchSlider.run(SKAction.sequence([wait2,SKAction.fadeAlpha(to: 0, duration: 0.5)]))
                volumeSlider.run(SKAction.sequence([wait2,SKAction.fadeAlpha(to: 0, duration: 0.5)]))
                shapeNodes[0].run(SKAction.sequence([wait2,SKAction.fadeAlpha(to: 0, duration: 0.5)]))
                pablo.alpha = 0
                
                let congrats = SKSpriteNode(imageNamed: "calibrated")
                congrats.position.x = 400
                congrats.position.y = 450
                congrats.zPosition = 7
                congrats.alpha = 0
                addChild(congrats)
                congrats.run(SKAction.sequence([appear,fadeOut]))
                
                pablo.run(SKAction.wait(forDuration: 1), completion: killSound)
                speech.alpha = 0
                
                changeTexture = SKAction.setTexture(SKTexture(imageNamed: "speech9"))
                speech.run(SKAction.sequence([wait3,changeTexture,wait,appear]))
                speech.position = CGPoint(x: 480, y: 480)
                background.run(SKAction.sequence([wait3,SKAction.setTexture(SKTexture(imageNamed: "background5"))]))

                button.position.x = 650
                button.run(SKAction.sequence([wait3,wait2,appear]))
                pablo2.run(SKAction.sequence([wait3,move3]))
             
            }
        }
        
        setSlider1 = 0
        setSlider2 = 0
    }

    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}

