import UIKit
import SpriteKit


public class ViewController: UIViewController {
    var skview: SKView!
    
    
//    public var uiview = UIView(frame: CGRect(x: 0, y: 0, width: 260, height: 62))

//    public var graphWidth: CGFloat = 1
//
//    public var amplitude: CGFloat = 1
//
//    public var periods = 3.0
    
    
    public override func viewDidLoad() {
        skview = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 600))
        let scene = GameScene2(size: CGSize(width: 800, height: 600))
        scene.scaleMode = .aspectFit
        skview.presentScene(scene)
        self.view = skview

//        uiview.translatesAutoresizingMaskIntoConstraints = false



//        uiview.contentMode.scaleAspectFit = 1
//        view.addSubview(uiview)
//
//        uiview.widthAnchor.constraint(equalTo: skview.widthAnchor, multiplier: 0.325).isActive = true
//        uiview.heightAnchor.constraint(equalTo: skview.heightAnchor, multiplier: 0.104).isActive = true
//        uiview.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
//        uiview.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true

//        let bounds = uiview.frame
//        
//        let width = bounds.width
//        let height = bounds.height
//
//
//        let origin = CGPoint(x: 0, y: 0)
//
//        let path = UIBezierPath()
//        path.move(to: origin)
//
//        let limit = 360 * periods
//        
//        
//        for angle in stride(from: 5.0, through: limit, by: 5.0) {
//            var x = origin.x + CGFloat(angle / limit) * width * graphWidth
//            var y = origin.y - CGFloat(sin(angle / 180.0 * .pi)) * height * amplitude
//            path.addLine(to: CGPoint(x: x, y: y))
//            
//        }
//
//        UIColor.red.setStroke()
//        path.lineWidth = 3
//        //        path.stroke()
//
//        //        UIColor.red.setFill()
//        //        path.fill()
//        
//        uiview.layer.sublayers?.removeAll()
//        
//        let layer = CAShapeLayer()
//        layer.zPosition = 6
//        
//        layer.path = path.cgPath
//        layer.strokeColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
//        layer.fillColor = nil
//        layer.lineWidth = 3
//        layer.lineCap = .round
//
//        uiview.layer.addSublayer(layer)
//
//        let animation1 = CABasicAnimation(keyPath: "strokeEnd")
//        animation1.fromValue = 0
//        animation1.toValue = 1
//
//
//        let animation2 = CABasicAnimation(keyPath: "strokeEnd")
//        animation2.fromValue = 0
//        animation2.toValue = 1
//
//        let animations = CAAnimationGroup()
//        animations.animations = [animation1, animation2]
//        animations.duration = 1
//        layer.add(animations, forKey: "line")
//

    }

}


