import SpriteKit
import PlaygroundSupport

public class GameScene: SKScene {
    let background = SKSpriteNode(imageNamed: "background")
    var pablo = SKSpriteNode(imageNamed: "pablo1")
    var speech = SKSpriteNode(imageNamed: "speech1")
    var button = SKSpriteNode(imageNamed: "button1")
    var changeTexture = SKAction.setTexture(SKTexture(imageNamed: "pablo2"))
    
    public func changeText(texture: String) {
        changeTexture = SKAction.setTexture(SKTexture(imageNamed: texture))
    }
    
    let fadeOut = SKAction.fadeAlpha(to: 0, duration: 0)
    
    var frameKey = 0
    
    let move1 = SKAction.move(to: CGPoint(x: 130, y: 230), duration: 0.5)
    
    let wait = SKAction.wait(forDuration: 0.5)
    let wait1 = SKAction.wait(forDuration: 1.5)
    let appear = SKAction.fadeAlpha(to: 1, duration: 1)
    let appear1 = SKAction.fadeAlpha(to: 1, duration: 1.5)
    
    


    override public func didMove(to view: SKView) {
        pablo.position.x = -100
        pablo.position.y = 300
        pablo.zPosition = 3
        
        pablo.run(move1)
        
        speech.position = CGPoint(x: 470, y: 450)
        speech.zPosition = 3
        speech.alpha = 0
        
        speech.run(SKAction.sequence([wait,appear]))
        
        button.position = CGPoint(x: 620, y: 360)
        button.alpha = 0
        button.zPosition = 3
        
        button.run(SKAction.sequence([wait1,appear1]))
        
        background.position.x = self.frame.midX
        background.position.y = self.frame.midY
        background.zPosition = 2

        addChild(button)
        addChild(background)
        addChild(pablo)
        addChild(speech)

    }

    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint) {
        if button.contains(pos) {
            switch frameKey {
            case 0:
                changeText(texture: "speech2")
                speech.run(SKAction.sequence([fadeOut,changeTexture,appear]))
                changeText(texture: "button2")
                button.run(SKAction.sequence([fadeOut,changeTexture,wait1,appear1]))
                pablo.texture = SKTexture(imageNamed: "pablo2")
                pablo.xScale = 0.87
                pablo.position = CGPoint(x: 130, y: 230)
                button.position = CGPoint(x: 620, y: 360)
                frameKey += 1
            case 1:
                changeText(texture: "speech3")
                speech.run(SKAction.sequence([fadeOut,changeTexture,appear]))
                changeText(texture: "button3")
                button.run(SKAction.sequence([fadeOut,changeTexture,wait1,appear1]))
                pablo.texture = SKTexture(imageNamed: "pablo3")
                pablo.xScale = 1.15
                pablo.position = CGPoint(x: 130, y: 230)
                button.position = CGPoint(x: 620, y: 360)
                frameKey += 1
            case 2:
                PlaygroundPage.current.navigateTo(page: .next)
            default:
                frameKey = 0
            }
        }
    }

    func touchMoved(toPoint pos : CGPoint) {

    }

    func touchUp(atPoint pos : CGPoint) {
    }

    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}

