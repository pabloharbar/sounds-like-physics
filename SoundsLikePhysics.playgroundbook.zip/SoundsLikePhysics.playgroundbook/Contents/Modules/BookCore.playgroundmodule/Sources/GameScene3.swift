import Foundation
import SpriteKit
import UIKit
import AVKit
import AVFoundation



public class GameScene3: SKScene {
    var prevpoint = CGPoint()
    var release = 0
    public var set = 0
    public var alternate = true
    let startingPitch = Float(0)
    
    var audioFilePlayer = [AVAudioPlayerNode]()
    var auTimePitch: AVAudioUnitTimePitch!
    var auTimePitch1: AVAudioUnitTimePitch!
    var audioFileBuffer: AVAudioPCMBuffer!
    var audioFileBuffer1: AVAudioPCMBuffer!
    
    
    var volume: Float = 0

    
    let fade = SKAction.fadeOut(withDuration: 2)
    let dim = SKAction.scaleY(to: 0.2, duration: 0.2)
    let grow = SKAction.scaleY(to: 20, duration: 0.2)
    
    
    public func startSound(volume: Float) {
        // Do any additional setup after loading the view, typically from a nib.
        audioFilePlayer.append(AVAudioPlayerNode())
        audioFilePlayer.append(AVAudioPlayerNode())
        
        do{
            let filePath: String = Bundle.main.path(forResource: "C2-Bass", ofType: "mp3")!
            let filePath1: String = Bundle.main.path(forResource: "C2-Piano", ofType: "mp3")!
            let fileURL: URL = URL(fileURLWithPath: filePath)
            let fileURL1: URL = URL(fileURLWithPath: filePath1)
            var audioFile: AVAudioFile!
            var audioFile1: AVAudioFile!
            try audioFile = AVAudioFile(forReading: fileURL)
            try audioFile1 = AVAudioFile(forReading: fileURL1)
            let audioFormat = audioFile.processingFormat
            let audioFormat1 = audioFile1.processingFormat
            let audioFrameCount = UInt32(audioFile.length)
            let audioFrameCount1 = UInt32(audioFile1.length)
            audioFileBuffer = AVAudioPCMBuffer(pcmFormat: audioFormat, frameCapacity: audioFrameCount)
            audioFileBuffer1 = AVAudioPCMBuffer(pcmFormat: audioFormat1, frameCapacity: audioFrameCount1)
            try audioFile.read(into: audioFileBuffer)
            try audioFile1.read(into: audioFileBuffer1)
            
            let mainMixer = audioEngine.mainMixerNode
            audioEngine.attach(audioFilePlayer[0])
            audioEngine.attach(audioFilePlayer[1])
            
            auTimePitch = AVAudioUnitTimePitch()
            auTimePitch.pitch = startingPitch
            auTimePitch1 = AVAudioUnitTimePitch()
            auTimePitch1.pitch = startingPitch
            audioEngine.attach(auTimePitch)
            audioEngine.attach(auTimePitch1)
            audioEngine.connect(audioFilePlayer[0], to: auTimePitch, format: mainMixer.outputFormat(forBus: 0))
            audioEngine.connect(audioFilePlayer[1], to: auTimePitch1, format: mainMixer.outputFormat(forBus: 0))
            audioEngine.connect(auTimePitch, to: mainMixer, format: mainMixer.outputFormat(forBus: 0))
            audioEngine.connect(auTimePitch1, to: mainMixer, format: mainMixer.outputFormat(forBus: 0))
            
            try audioEngine.start()
            audioFilePlayer[0].play()
            audioFilePlayer[1].play()
            
            audioFilePlayer[0].scheduleBuffer(audioFileBuffer, at: nil, options:.loops, completionHandler: nil)
            audioFilePlayer[1].scheduleBuffer(audioFileBuffer1, at: nil, options:.loops, completionHandler: nil)
        }catch{
            print("erro start audio engine")
        }
    }

    
    public func color(pos: CGPoint) -> UIColor{
        let scale = 8.0 - pos.x / 100
        let scale7 = 7.0 - pos.x / 115
        let scale9 = pos.x / 88
        var red = 0.0, green = 0.0, blue = 0.0
        switch set {
        case 0:
            switch scale7 {//Verde
            case 0..<1:
                red = Double(204 - scale7 * 46)
                green = Double(255 - scale7 * 15)
                blue = Double(51 - scale7 * 25)
                break
            case 1..<2:
                red = Double(158 - (scale7 - 1) * 46)
                green = Double(240 - (scale7 - 1) * 16)
                blue = Double(26 - (scale7 - 1) * 26)
                break
            case 2..<3:
                red = Double(112 - (scale7 - 2) * 56)
                green = Double(224 - (scale7 - 2) * 48)
                blue = Double(0)
                break
            case 3..<4:
                red = Double(56 - (scale7 - 3) * 56)
                green = Double(176 - (scale7 - 3) * 48)
                blue = Double(0)
                break
            case 4..<5:
                red = Double(0)
                green = Double(128 - (scale7 - 4) * 14)
                blue = Double(0)
                break
            case 5..<6:
                red = Double(0)
                green = Double(114 - (scale7 - 5) * 14)
                blue = Double(0)
                break
            case 6..<7:
                red = Double(0)
                green = Double(100 - (scale7 - 6) * 25)
                blue = Double((scale7 - 6) * 35)
                break
            default:
                red = 204
                blue = 255
                green = 51
            }
        case 1:
            switch scale9 {//Laranja
            case 0..<1:
                red = Double(255)
                green = Double(123 + scale9 * 13)
                blue = Double(0)
                break
            case 1..<2:
                red = Double(255)
                green = Double(136 + (scale9 - 1) * 13)
                blue = Double(0)
                break
            case 2..<3:
                red = Double(255)
                green = Double(149 + (scale9 - 2) * 13)
                blue = Double(0)
                break
            case 3..<4:
                red = Double(255)
                green = Double(162 + (scale9 - 3) * 8)
                blue = Double(0)
                break
            case 4..<5:
                red = Double(255)
                green = Double(170 + (scale9 - 4) * 13)
                blue = Double(0)
                break
            case 5..<6:
                red = Double(255)
                green = Double(183 + (scale9 - 5) * 12)
                blue = Double(0)
                break
            case 6..<7:
                red = Double(255)
                green = Double(195 + (scale9 - 6) * 13)
                blue = Double(0)
                break
            case 7..<8:
                red = Double(255)
                green = Double(208 + (scale9 - 7) * 13)
                blue = Double(0)
                break
            case 8..<9:
                red = Double(255)
                green = Double(221 + (scale9 - 8) * 13)
                blue = Double(0)
                break
            default:
                red = Double(255)
                blue = Double(123)
                green = Double(0)
            }
        default:
            switch scale {//Azul
            case 0..<1:
                red = Double(169 - scale * 32)
                green = Double(214 - scale * 20)
                blue = Double(229 - scale * 12)
                break
            case 1..<2:
                red = Double(137 - (scale - 1) * 40)
                green = Double(194 - (scale - 1) * 29)
                blue = Double(217 - (scale - 1) * 23)
                break
            case 2..<3:
                red = Double(97 - (scale - 2) * 27)
                green = Double(165 - (scale - 2) * 22)
                blue = Double(194 - (scale - 2) * 19)
                break
            case 3..<4:
                red = Double(70 - (scale - 3) * 28)
                green = Double(143 - (scale - 3) * 32)
                blue = Double(175 - (scale - 3) * 24)
                break
            case 4..<5:
                red = Double(42 - (scale - 4) * 41)
                green = Double(111 - (scale - 4) * 32)
                blue = Double(151 - (scale - 4) * 17)
                break
            case 5..<6:
                red = Double(1)
                green = Double(79 - (scale - 5) * 6)
                blue = Double(134 - (scale - 5) * 10)
                break
            case 6..<7:
                red = Double(1)
                green = Double(73 - (scale - 6) * 15)
                blue = Double(124 - (scale - 6) * 25)
                break
            case 7..<8:
                red = Double(1)
                green = Double(58 - (scale - 7) * 16)
                blue = Double(99 - (scale - 7) * 25)
                break
            default:
                red = 169
                blue = 214
                green = 229
            }
        }
        
        return UIColor(
            red: CGFloat(red) / 255.0,
            green: CGFloat(green) / 255.0,
            blue: CGFloat(blue) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    public override func didMove(to view: SKView) {
        // Get label node from scene and store it for use later

        // Create shape node to use during mouse interaction
        startSound(volume: 0.0)
        audioFilePlayer[0].volume = 0
        audioFilePlayer[1].volume = 0
    }
    
    @objc static public override var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        if alternate == true{
            switch set {
                case 0:
                    set = 1
                case 1:
                    set = 0
                default:
                    set = 0
            }
        }
    }
    

    
    func touchMoved(toPoint pos : CGPoint) {
        let size = (pos.y + 100) / 300
        //Usar spritenode e asset, blendfactor -> 1 (para trocar cor)
        let point = SKShapeNode(circleOfRadius: size)
        point.strokeColor = .clear
        point.fillColor = color(pos: pos)
        point.position = pos
        
        point.run(fade)
        
        let tan = (pos.y - prevpoint.y) / (pos.x - prevpoint.x)
        var alpha = atan(tan)
        if release == 0 {
            alpha = 0
        }
        let rotation = SKAction.rotate(byAngle: alpha, duration: 0)
        point.run(rotation)
        


        let ScalingSequence = SKAction.sequence([dim,grow])

        let fingerTapScaleForever = SKAction.repeatForever(ScalingSequence)
        point.run(fingerTapScaleForever)
        
        
        
        let distance = pow(((prevpoint.x - pos.x) * (prevpoint.x - pos.x) + (prevpoint.y - pos.y) * (prevpoint.y - pos.y)), 0.5)
        
        if (distance >= size) && (release == 1) {
            let replicate = Int(distance / size) + 1
            var midpoint = [SKShapeNode]()
            var xpos = CGFloat(0), ypos = CGFloat(0)
            
            //Olhar nesse trecho para otimizar

            for i in 0...replicate {
        
                let node = SKShapeNode(circleOfRadius: size)
                node.strokeColor = .clear

                
                let index = CGFloat(i + 1)
                let factor = index / CGFloat(replicate)
                
                xpos = (pos.x - prevpoint.x) * factor
                ypos = (pos.y - prevpoint.y) * factor
                
                node.position = CGPoint(x: prevpoint.x + xpos, y: prevpoint.y + ypos)
                node.fillColor = color(pos: node.position)
                node.run(fade)
                node.run(rotation)
                node.run(fingerTapScaleForever)
                midpoint.append(node)
                addChild(node)
                
           }
        }
        
        addChild(point)
        
        
        audioFilePlayer[set].volume = 0.1 + Float(pos.y / 600)
        auTimePitch.pitch = 1200 * Float(pos.x / 800) + 100
        auTimePitch1.pitch = 1200 * Float(pos.x / 800) + 100
        
        prevpoint = pos
        release = 1
    }
    
    
    func touchUp(atPoint pos : CGPoint) {

        audioFilePlayer[0].volume = 0
        audioFilePlayer[1].volume = 0
        release = 0
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    public override func update(_ currentTime: TimeInterval) {
 
        // Called before each frame is rendered
    }
}


